﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ShopBridgeUI.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using X.PagedList;
namespace ShopBridgeUI.Controllers
{
    public class InventoryController : Controller
    {
        // GET: InventoryController
      
        public InventoryController()
        {
           
        }

        public async Task<ActionResult> Index(int? page)
        {
            List<Product> products = new List<Product>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:52539/api/products/"))
                {
                    string apiRespone = await response.Content.ReadAsStringAsync();
                    products = JsonConvert.DeserializeObject<List<Product>>(apiRespone);
                }
            }
           if(page>products.ToPagedList(page ?? 1, 3).PageCount)
            {
                return RedirectToAction("Error");           
            }
            return View(products.ToPagedList(page??1,3));            
        }

        // GET: InventoryController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: InventoryController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Product product)
        {
            using (var httpClient = new HttpClient())
            {
               
                var postproduct = await httpClient.PostAsJsonAsync("http://localhost:52539/api/products/", product);

                //var postResult = postproduct.Result;

                if (postproduct.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Index));
                }
            }


            return View(product);
        }

        // GET: InventoryController/Edit/5
        public async Task<ActionResult> Edit(int Id)
        {
            Product product = new Product();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:52539/api/products/" + Id))
                {
                    string apiRespone = await response.Content.ReadAsStringAsync();
                    product = JsonConvert.DeserializeObject<Product>(apiRespone);
                }
                return View(product);
            }
        }

        // POST: InventoryController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(Product product)
        {
            using (var httpClient = new HttpClient())
            {
                var postproduct = await httpClient.PutAsJsonAsync("http://localhost:52539/api/products/", product);

                //var postResult = postproduct.Result;

                if (postproduct.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    return View(product);
                }
            }

        }

        // GET: InventoryController/Delete/5
        public async Task<ActionResult> Delete(int Id)
        {
            Product product = new Product();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:52539/api/products/" + Id))
                {
                    string apiRespone = await response.Content.ReadAsStringAsync();
                    product = JsonConvert.DeserializeObject<Product>(apiRespone);
                }
                return View(product);
            }
        }

        // POST: InventoryController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Delete(Product product)
        {
            using (var httpClient = new HttpClient())
            {
                var postproduct = await httpClient.DeleteAsync("http://localhost:52539/api/products/"+ product.Id);

                //var postResult = postproduct.Result;

                if (postproduct.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    return View();
                }
            }

        }

        public ActionResult Error()
        {
            return View();
        }
    }
}
