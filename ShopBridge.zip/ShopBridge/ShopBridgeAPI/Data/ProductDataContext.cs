﻿using Microsoft.EntityFrameworkCore;
using ShopBridgeAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridgeAPI.Data
{
    public class ProductDataContext : DbContext
    {
        public ProductDataContext(DbContextOptions<ProductDataContext> options):base(options)    {  }
        public DbSet<Product> Products { get; set; }
    }
}
